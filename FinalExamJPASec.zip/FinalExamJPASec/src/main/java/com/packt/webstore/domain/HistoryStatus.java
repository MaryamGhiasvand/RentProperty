package com.packt.webstore.domain;

public enum HistoryStatus {
	CANCELED,CONFIRMED,ONRENT,CONTRACTEXPIRED

}